<!DOCTYPE html>
<html lang="en">
<head>
<title>MC-AT - Bot Komutlar</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="img/1000.png" type="image/x-icon" />
<link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/owl.carousel.min2.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/aos.css">
<link rel="stylesheet" href="css/ionicons.min.css">
<link rel="stylesheet" href="css/bootstrap-datepicker.css">
<link rel="stylesheet" href="css/jquery.timepicker.css">
<link rel="stylesheet" href="css/flaticon.css">
<link rel="stylesheet" href="css/icomoon.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/dropdown.css">

<script charset="UTF-8" src="//cdn.sendpulse.com/js/push/9129e52d8d5ed96c0dd4697261f0d593_1.js" async type="329f14dacd3629294a6e99d5-text/javascript"></script>

<script type="329f14dacd3629294a6e99d5-text/javascript">
    jQuery('.switcher .selected').click(function() {if(!(jQuery('.switcher .option').is(':visible'))) {jQuery('.switcher .option').stop(true,true).delay(100).slideDown(500);jQuery('.switcher .selected a').toggleClass('open')}});
    jQuery('.switcher .option').bind('mousewheel', function(e) {var options = jQuery('.switcher .option');if(options.is(':visible'))options.scrollTop(options.scrollTop() - e.originalEvent.wheelDelta);return false;});
    jQuery('body').not('.switcher').mousedown(function(e) {if(jQuery('.switcher .option').is(':visible') && e.target != jQuery('.switcher .option').get(0)) {jQuery('.switcher .option').stop(true,true).delay(100).slideUp(500);jQuery('.switcher .selected a').toggleClass('open')}});
</script>
<li style="display:none" id="google_translate_element2"></li>
<script type="329f14dacd3629294a6e99d5-text/javascript">
    function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'tr',autoDisplay: false}, 'google_translate_element2');}
</script><script type="329f14dacd3629294a6e99d5-text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>
<script type="329f14dacd3629294a6e99d5-text/javascript">
    function GTranslateGetCurrentLang() {var keyValue = document.cookie.match('(^|;) ?googtrans=([^;]*)(;|$)');return keyValue ? keyValue[2].split('/')[2] : null;}
    function GTranslateFireEvent(element,event){try{if(document.createEventObject){var evt=document.createEventObject();element.fireEvent('on'+event,evt)}else{var evt=document.createEvent('HTMLEvents');evt.initEvent(event,true,true);element.dispatchEvent(evt)}}catch(e){}}
    function doGTranslate(lang_pair){if(lang_pair.value)lang_pair=lang_pair.value;if(lang_pair=='')return;var lang=lang_pair.split('|')[1];if(GTranslateGetCurrentLang() == null && lang == lang_pair.split('|')[0])return;var teCombo;var sel=document.getElementsByTagName('select');for(var i=0;i<sel.length;i++)if(sel[i].className=='goog-te-combo')teCombo=sel[i];if(document.getElementById('google_translate_element2')==null||document.getElementById('google_translate_element2').innerHTML.length==0||teCombo.length==0||teCombo.innerHTML.length==0){setTimeout(function(){doGTranslate(lang_pair)},500)}else{teCombo.value=lang;GTranslateFireEvent(teCombo,'change');GTranslateFireEvent(teCombo,'change')}}
    if(GTranslateGetCurrentLang() != null)jQuery(document).ready(function() {jQuery('div.switcher div.selected a').html(jQuery('div.switcher div.option').find('img[alt="'+GTranslateGetCurrentLang()+'"]').parent().html());});
</script>
<style>
  /* Translate */
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
  </style>


<script async src="https://www.googletagmanager.com/gtag/js?id=UA-69267770-1" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script type="329f14dacd3629294a6e99d5-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-69267770-1');
</script>
<script type="329f14dacd3629294a6e99d5-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-69267770-1');
  
  

</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
<div class="container">
<a class="navbar-brand" href="./">MC-AT</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="oi oi-menu"></span> Menu
</button>
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav ml-auto">
<li class="nav-item active"><a href="./" class="nav-link">Ana sayfa</a></li>
<li class="nav-item"><a href="komutlar.php" class="nav-link">Komutlar</a></li>
<li class="nav-item"><a class="nav-link" href="premium.php">Premium</a></li>
<li class="nav-item"><a href="https://www.muratkim.com/" target="blank" class="nav-link">Blog</a></li>
<li class="nav-item"><a href="../steam/durum.php" class="nav-link">Status</a></li>
<li class="nav-item"><a href="../destek" target="blank" class="nav-link">Discordumuz</a></li>
<li class="nav-item dropdown">
<a href="#" class="nav-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
Language
</a>
<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|en');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="English" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/english.png" height="18" width="22" alt="english" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|de');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Deutsch" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/german.png" height="18" width="22" alt="german" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|ar');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Arabic" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/arabic.png" height="18" width="22" alt="arabic" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|ru');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Russian" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/russian.png" height="18" width="22" alt="russian" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|fr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="French" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/france.png" height="18" width="22" alt="french" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|IN');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="India" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/india.png" height="18" width="22" alt="india" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|az');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Azerice" class="nturl dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/azerbaycan.png" height="18" width="22" alt="azerbaijani" /></a>
<a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; doGTranslate('tr|tr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Türkçe" class="nturl selected dropdown-item" data-cf-modified-329f14dacd3629294a6e99d5-=""><img src="./images/turkish.png" height="18" width="22" alt="turkish" /></a>
</div>
</li>
<li class="nav-item cta"><a href="../discord/" class="nav-link"><span>Panele gir</span></a></li>
</ul>
</div>
</div>
</nav>
<section class="home-slider owl-carousel">
<div class="slider-item bread-item" style="background-image: url(images/logu.png);" data-stellar-background-ratio="0.5">
<div class="overlay"></div>
<div class="container-fluid">
<div class="row slider-text align-items-center justify-content-center" data-scrollax-parent="true">
<div class="col-md-8 mt-5 text-center col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="./">Ana Sayfa</a></span> <span>Komutlar</span></p>
<h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">MC-AT Komutları</h1>
</div>
</div>
</div>
</div>
</section>
<section class="ftco-section bg-light">
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>

<ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-3997950661380123" data-ad-slot="4603315959"></ins>
<script type="329f14dacd3629294a6e99d5-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="container">
<h2>Komutlar</h2>
<input type="textt" id="myInput" onkeyup="if (!window.__cfRLUnblockHandlers) return false; myFunction()" placeholder="Ne Arıyorsunuz ? : Aradığınız Komutu Yazın.." title="Arayacağınız Komutu Anahtar Kelime Olarak Giriniz." data-cf-modified-329f14dacd3629294a6e99d5-="">
<table id="myTable">
<tr class="header">
<th style="width:20%;">Komut</th>
<th style="width:60%;">Açıklama</th>
<th style="width:20%;">Kullanım</th>
</tr>
<tr>
<td><strong>yardım</strong></td>
<td>Bot Komutlarını Görmek İçin.</td>
<td>!yardım</td>
</tr>
<tr>
<td><strong>Botbilgi</strong></td>
<td>Bot Hakkında Bilgi Edinebilmen İçin Yararlıdır.</td>
<td>!Botbilgi</td>
</tr>
<tr>
<td><strong>Profiline Bakmak İçin</strong></td>
<td>Bir kişinin profilini gösterir.</td>
<td>!Profil</td>
</tr>
<tr>
<td><strong>davet</strong></td>
<td>Bu Link İle Sunucuna Küfür-Reklam Engelleme Botunu Ekleyebilirsin.</td>
<td>!davet</td>
</tr>
<tr>
<td><strong>küfür Kapat</strong></td>
<td>Bu Komut İle Küfür Korumasını Belirlenen Yazı Kanalında Engelleyebilirsin.</td>
<td>!küfürkapat</td>
</tr>
<tr>
<td><strong>Küfür Aç</strong></td>
<td>Bu Komut İle Küfür Korumasını Belirlenen Yazı Kanalında Aktif Edebilirsin.</td>
<td>!küfüraç</td>
</tr>
<tr>
<td><strong>Reklam Aç</strong></td>
<td>Bu Komut İle Reklam Korumasını Aktif Edebilirsin.</td>
<td>!Reklamaç</td>
</tr>
<tr>
<td><strong>Reklam Kapat</strong></td>
<td>Bu Komut İle Reklam Korumasını Kapatabilirsin.</td>
<td>!ReklamKapat</td>
</tr>
<tr>
<td><strong>Hoşgeldin Kapat</strong></td>
<td>Bu Komut İle Sunucuya Girdiklerinde Atılan Otomatik Hoşgeldin Mesajını Kapatabilirsin.</td>
<td>!Hoşgeldinkapat</td>
</tr>
<tr>
<td><strong>Hoşgeldin Aç</strong></td>
<td>Bu Komut İle Sunucuya Girdiklerinde Atılan Otomatik Hoşgeldin Mesajını Aktif Edebilirsin.</td>
<td>!Hoşgeldinaç</td>
</tr>
<tr>
<td><strong>Otomatik Bot Silici Aç</strong></td>
<td>Sadece O Yazışma Kanalında Tüm Botların Mesajlarını (2) Dakika Sonra Otomatik Siler.</br> Chatiniz Daha Temiz Görünür. Aktif Edebilirsin.</td>
<td>!otobotsiliciaç</td>
</tr>
<tr>
<td><strong>Otomatik Bot Silici Kapat</strong></td>
<td>Sadece O Yazışma Kanalında Bu Özelliği Kapatabilirsin.</td>
<td>!otobotsilicikapat</td>
</tr>
<tr>
<td><strong>ReklamcıKick Aç</strong></td>
<td>Reklamcıları (3) Kez Uyardıktan Sonra Sunucudan Atar. </br>Bunun Çalışması İçin Botun Rolü Üyelerden Yüksekte Olmak Zorundadır.in.</td>
<td>!reklamkickaç</td>
</tr>
<tr>
<td><strong>ReklamcıKick kapat</strong></td>
<td>Reklamcıları (3) Kez Uyardıktan Sonra Sunucudan Atma Özelliğini Devredışı Bırakır.</td>
<td>!reklamkickkapat</td>
</tr>
<tr>
<td><strong>Otorol</strong></td>
<td>Sunucuya Yeni Katılan Üyelere Otomatik Ayarlanan Rolü Verir.</br>Örnek Kullanım: !otorol @Roletiket #kanaletiket </br>Bunun Çalışması İçin Botun Rolü Üyelerden Yüksekte Olmak Zorundadır.</td>
<td>!otorol</td>
</tr>
<tr>
<td><strong>Güvenlik Sistemi</strong></td>
<td>"güvenlik" Adında Bir Text Channel Açmanız Gerek.</br> Şüpheli Veya Reklam Yapma İhtimali Olan Üyeleri Gösterecektir.</td>
<td>!güvenlik</td>
</tr>
<tr>
<td><strong>Koruma Sistemi</strong></td>
<td>"Yönetici" Yetkisi Vermeniz Yeterlidir Aşşağıdaki Saldırı Tipini Önler Spambot Koruması.</td>
<td>!koruma</td>
</tr>
<tr>
<td><strong>Sunucu Tanıt</strong></td>
<td>Bu Komut İle Kendi Sunucunu Botun Destek Sunucusunda Ücretsiz Paylaşabilirsin 24 Saatte Bir.</td>
<td>!Sunucutanıt</td>
</tr>
<tr>
<td><strong>Oto Cevap</strong></td>
<td>Oto Cevap Özelliği Siteden Ayaralanabilir..</td>
<td>!otocevap</td>
</tr>
<tr>
<td><strong>Oto Tag</strong></td>
<td>Sunucunuza katılan kişilerin isimlerine tag ekleyebilirsiniz. İşinize yaraması için !tagsistemi okuyun lütfen...</td>
<td>!ototag / !tagsistemi</td>
</tr>
<tr>
<td><strong>Kayıt Sistemi</strong></td>
<td>!kayıt Mahmut 18 şeklinde üyeleri otomatik kayıt etme sistemi.</td>
<td>!kayıtsistemi</td>
</tr>
<tr>
<td><strong>Hoşgeldin Bay Bay Sistemi</strong></td>
<td>Resimli Hoş Geldin / Resimli Bay Bay Sistemi.</td>
<td>!hg-bb-sistemi</td>
</tr>
<tr>
<td><strong>Gold Üye</strong></td>
<td>Bot Üzerinde Premium Üyelik.</td>
<td>!gold</td>
</tr>
<tr>
<td><strong>Puan Sistemi</strong></td>
<td>Puan Marketi.</td>
<td>!P-market</td>
</tr>
<tr>
<td><strong>Site Doğrulama</strong></td>
<td>Yeni katılan üyeler eğer hesaplarını siteden hesaplarını onaylamazlarsa konuşmasını 2 dakika susturur.</td>
<td>!sitedoğrulamaaç / !sitedoğrulamakapat</td>
</tr>
<tr>
<td><strong>Reklam İsim Ban</strong></td>
<td>Sunucunuza katılan kişimlerin isminde Discord,Davet,İnvite,Join kelimeleri geçiyorsa otomatik banlar.</td>
<td>!reklamisimbanaç / !reklamisimbankapat</td>
</tr>
<tr>
<td><strong>Sayaç Ayarlama</strong></td>
<td>Sunucunuzda sayaç özelliğini açabilirsiniz.!sayaç #kanal <sayı> .</td>
<td>!sayaç / !sayaçkapat / !sayaçaç</td>
</tr>
<tr>
<td><strong>Link Engelleme Sistemi</strong></td>
<td>.com .net Gibi linklerin Paylaşımını o kanalda engeller.</td>
<td>!link-engel-aç / !link-engel-kapat</td>
</tr>
<tr>
<td><strong>Bancı Sistemi</strong></td>
<td>Sunucunuzda ban koruması yapmak için bu özelliği kesinlikle kullanınız!!!</td>
<td>!banözelliği / !bansistemi</td>
</tr>
<tr>
<td><strong>Sunucunuzu Tanıtır</strong></td>
<td>Sunucunuz'un davet linkini destek sunucusunda paylaşır.</td>
<td>!sunucutanıt</td>
</tr>
<tr>
<td><strong>Mesaj Silmek</strong></td>
<td>Mesajları Toplu Silmek İçin Kullanılır</td>
<td>!sil 1-400</td>
</tr>
<tr>
<td>Puan Menü<strong></strong></td>
<td>Puan Marketi Menü.</td>
<td>!P-menü</td>
</tr>
<tr>
<td><strong>Sunucu PP Atar</strong></td>
<td>Sunucu fotoğrafını gösterir.</td>
<td>!Sunucu-pp</td>
</tr>
<tr>
<td><strong>Kredim</strong></td>
<td>Sitedeki kredinizi gösterir ve kalan gold üye sürenizi.</td>
<td>!kredim</td>
</tr>
<tr>
<td><strong>Oy Vermek İçin</strong></td>
<td>Bota oy vermek için.</td>
<td>!oyver</td>
</tr>
<tr>
<td><strong>Web Panel</strong></td>
<td>Botu siteden yönetebilirsin.</td>
<td>!webpanel</td>
</tr>
<tr>
<td><strong>Kral Olmak İçin</strong></td>
<td>Kral olabilirsin.</td>
<td>!Kralol</td>
</tr>
<tr>
<td><strong>Maymun Olmak İçin</strong></td>
<td>Maymun olabilirsin.</td>
<td>!Maymunol</td>
</tr>
<tr>
<td><strong>Yılan Olmak İçin</strong></td>
<td>Yılan olabilirsin.</td>
<td>!Yılanol</td>
</tr>
<tr>
<td><strong>Adam Olmak İçin</strong></td>
<td>Adam olabilirsin.</td>
<td>!Adamol</td>
</tr>
<tr>
<td><strong>Kedi Olmak İçin</strong></td>
<td>Kedi olabilirsin.</td>
<td>!Kediol</td>
</tr>
<tr>
<td><strong>Aşk Seviyeni Görmek İçin</strong></td>
<td>Aşk seviyeni görebilirsin.</td>
<td>!aşk</td>
</tr>
<tr>
<td><strong>Token Almak İçin</strong></td>
<td>Botun tokenini alabilirsin.</td>
<td>!Token</td>
</tr>
<tr>
<td><strong>Tokat Atmak İçin</strong></td>
<td>Tokat atabilirsin.</td>
<td>!tokat </td>
</tr>
<tr>
<td><strong>Ayarlar</strong></td>
<td>sunucu ayarlarını gösterir..</td>
<td>!ayarlar</td>
</tr>
<tr>
<td><strong>Puanım</strong></td>
<td>puanınızı gösterir.</td>
<td>!puanım</td>
</tr>
<tr>
<td><strong>Duyuru</strong></td>
<td>Embed Duyuru Yapmanıza Yarar.</td>
<td>!duyuru</td>
</tr>
<tr>
<td><strong>Mute Sistemi</strong></td>
<td>Süreli susturma/mute sistemi üyelere süreli susturma atabilirsin. 10 dakika 1 saat vs.</td>
<td>!mute-sistemi</td>
</tr>
<tr>
<td><strong>Reklam Taraması</strong></td>
<td>Sunucudaki üyelerin oynuyor kısımlarında reklam varsa bildirir.</td>
<td>!reklam-taraması</td>
</tr>
<tr>
<td><strong>Ultra Sohbet Temizleyici</strong></td>
<td>Sunucunuzun sohbet temizliği için önerilir tüm komutları ve botların mesajlarını 5 saniyede bir temizler.</td>
<td>!utemizlikaç / !utemizlikkapat</td>
</tr>
<tr>
<td><strong>Slowmode</strong></td>
<td>Sunucudaki üyelerin oynuyor kısımlarında reklam varsa bildirir.</td>
<td>!slowmode / !yavaş-mod</td>
</tr>
<tr>
<td><strong>Rol Sistemi</strong></td>
<td>Rolleri yönet yetkisini üyeye vermeden rol verme yetkisini üyeye verebilirsiniz güvenlik için önerilir!</td>
<td>!rol-sistemi</td>
</tr>
<tr>
<td><strong>Geçici oda</strong></td>
<td>Sunucunuz için geçici oda kurup oda kirliliğinin önüne geçebilirsiniz!</td>
<td>!geçici-oda</td>
</tr>
<tr>
<td><strong>Anti Raid Bot Sistemi</strong></td>
<td>Sunucuya yabancı botların girmesini önler. Sadece sunucu sahibi onay verince giriş yapabilirler.</td>
<td>!anti-raid-bot-sistemi</td>
</tr>
<tr>
<td><strong>Koruma Log (Kayıt Odası) Tutar</strong></td>
<td>Koruma kayıtlarının gönderileceği kanalı belirler.</td>
<td>!koruma-log #logkanal</td>
</tr>
<tr>
<td><strong>Koruma Ban Limit</strong></td>
<td>Sunucuda birisi 10 dakika içerisinde belirlenen sayının üzerinde ban atarsa o üyeyi sunucundan atar. (kickler) Yönetici yetkisini ve botlarıda görür. (TAM KORUMA İÇİN İDEALDİR)</td>
<td>!koruma-banlimit (sayı)</td>
</tr>
<tr>
<td><strong>Koruma Kanal Limit</strong></td>
<td>30 dakika içerisinde bir üye tarafından belirtilen sayıdan fazla kanal silerse üye sunucudan atılır.</td>
<td>!koruma-kanallimit (sayı)</td>
</tr>
<tr>
<td><strong>Koruma Rol Limit</strong></td>
<td>30 dakika içerisinde bir üye tarafından belirtilen sayıdan fazla rol silinirse silen üye sunucudan atılır.</td>
<td>!koruma-rollimit (sayı)</td>
</tr>
<tr>
<td><strong>Ban Koruma Özelliği Açıp Kapatmak</strong></td>
<td>Ban koruma özelliğini açar kapatır.</td>
<td>!koruma-banlimit-sistemi (aç / kapat)</td>
</tr>
<tr>
<td><strong>Kanal Koruma Özelliği Açıp Kapatmak</strong></td>
<td>Kanal koruma özelliğini açar kapatır.</td>
<td>!koruma-kanal-sistemi (aç / kapat)</td>
</tr>
<tr>
<td><strong>Koruma Rol Limit Özelliği Açıp Kapatmak</strong></td>
<td>Rol koruma özelliğini açar kapatır.</td>
<td>!koruma-rollimit-sistemi (aç / kapat)</td>
</tr>
<tr>
<td><strong>Koruma Sistemini Kapatmak</strong></td>
<td>Sunucunuzun verilerini veritabanından siler. (ayarları baştan yapmanız gerekir)</td>
<td>!koruma-sistemi-sil</td>
</tr>
<tr>
<td><strong>Spam Bot Koruması</strong></td>
<td>Spambot korumasını gösterir.</td>
<td>!spambotkorumasi</td>
</tr>
<tr>
<td><strong>Güvenlik Seviyenizi Gösterir</strong></td>
<td>Sunucuya katılan üyelerin güvenilir olup olmadığını gösterir.</td>
<td>!güvenlikseviyesi</td>
</tr>
<tr>
<td><strong>Botun Dilini Değiştirmek İçin</strong></td>
<td>Botun Dilini Değiştirmek İçin Diller = Türkçe / İngilizce / Azerice</td>
<td>!lang</td>
</tr>
</table>
</div>
<script type="329f14dacd3629294a6e99d5-text/javascript">
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</section>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>

<ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-3997950661380123" data-ad-slot="4603315959"></ins>
<script type="329f14dacd3629294a6e99d5-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<section class="ftco-section testimony-section">
<div class="container">
<div class="row justify-content-center mb-5 pb-3">
<div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
<span class="subheading">Referanslarımız</span>
<h2 class="mb-4">Hakkımızda Söyledikleri</h2>
<p>MC-AT bot hakkında bazı değerlendirmeler.</p>
</div>
</div>
<div class="row ftco-animate">
<div class="col-md-12">
<div class="carousel-testimony owl-carousel ftco-owl">
<div class="item">
<div class="testimony-wrap p-4 pb-5">
<div class="user-img mb-5" style="background-image: url(images/zulafenomen.jpg)">
<span class="quote d-flex align-items-center justify-content-center">
<i class="icon-quote-left"></i>
</span>
</div>
<div class="text">
<p class="mb-5">Zula fenomen instagram sayfası olarak bizde discord açtık ve bot harika sunucumuzu koruyor güvendeyiz sizede öneririm ancak premium daha kaliteli premium alarak içiniz ekstra bir rahat bir şekilde uyuyabilirsiniz.</p>
<p class="name">Emin Can Kalkanlı</p>
<span class="position">instagramer</span>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap p-4 pb-5">
<div class="user-img mb-5" style="background-image: url(images/halilorenler.jpg)">
<span class="quote d-flex align-items-center justify-content-center">
<i class="icon-quote-left"></i>
</span>
</div>
<div class="text">
<p class="mb-5">Mc-At botunu sunucumuzu ilk açtığımızdan beri kullanıyoruz koruma sistemi olsun birçok özelliğinden faydalanıyoruz üyelerimiz seviyor sunucumuz korunuyor Mc-At sizlere öneririm ve kesinlikle tavsiye ederim.</p>
<p class="name">Halil Örenler</p>
<span class="position">Youtuber</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>

<ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-3997950661380123" data-ad-slot="4603315959"></ins>
<script type="329f14dacd3629294a6e99d5-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<footer class="ftco-footer ftco-bg-dark ftco-section">
<div class="container">
<div class="row mb-5">
<div class="col-md">
<div class="ftco-footer-widget mb-4">
<h2 class="ftco-heading-2">MC-AT</h2>
<p>Yazma Tutkusu</p>
<ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
<li class="ftco-animate"><a href="../destek" target="blank"><img src="https://discordapp.com/assets/1c8a54f25d101bdc607cec7228247a9a.svg" style="vertical-align: text-top; margin-left: 5px;" alt="Discord Sunucumuz" height="40" width="40"></a></li>
<li class="ftco-animate"><a href="https://www.youtube.com/channel/UCz5HO7Z9y5zZWdd9SNX_04Q" target="blank"><span class="icon-youtube"></span></a></li>
<li class="ftco-animate"><a href="/cdn-cgi/l/email-protection#2f4e4b4246416f425a5d4e5b444642014c4042"><span class="icon-envelope"></span></a></li>
</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-4 ml-md-5">
<h2 class="ftco-heading-2">Yararlı linkler</h2>
<ul class="list-unstyled">
<li><a href="https://www.mcadventuretime.com/" class="py-2 d-block">Minecraft Sunucusu</a></li>
<li><a href="../steam" class="py-2 d-block">Steam</a></li>
<li><a href="./premium.php" class="py-2 d-block">Premium</a></li>
<li><a href="../steam/golduye.php" class="py-2 d-block">Gold üye</a></li>
<li><a href="./komutlar.php" class="py-2 d-block">Komutlar</a></li>
<li><a href="../steam/yeniyil.php" class="py-2 d-block">Op Kasa</a></li>
</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-4">
<h2 class="ftco-heading-2">Linkler</h2>
<ul class="list-unstyled">
<li><a href="../discord" class="py-2 d-block">Panel</a></li>
<li><a href="https://www.muratkim.com/" target="blank" class="py-2 d-block">Blog</a></li>
<li><a href="../destek" class="py-2 d-block">Discord Sunucumuz</a></li>
<li><a href="/cdn-cgi/l/email-protection#6706030a0e09270a121506130c0e0a4904080a" class="py-2 d-block">İletişim</a></li>
<li><a href="#" class="py-2 d-block">Hakkımızda</a></li>
<li><a href="../davet" onclick="if (!window.__cfRLUnblockHandlers) return false; window.open(this.href, 'mywin', 'left=20,top=20,width=350,height=600,toolbar=1,resizable=0'); return false;" class="py-2 d-block" data-cf-modified-329f14dacd3629294a6e99d5-="">Botu Davet</a></li>
</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-4">
<h2 class="ftco-heading-2">iletişim</h2>
<div class="block-23 mb-3">
<ul>
<li><a href="/cdn-cgi/l/email-protection#4627222b2f28062b333427322d2f2b6825292b"><span class="icon icon-envelope"></span><span class="text"><span class="__cf_email__" data-cfemail="5d3c393034331d30282f3c29363430733e3230">[email&#160;protected]</span></span></a></li>
</ul>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12 text-center">
<p> Copyright muratkim.com &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="329f14dacd3629294a6e99d5-text/javascript">document.write(new Date().getFullYear());</script> Tüm hakları saklıdır</p>
<a href="//www.dmca.com/Protection/Status.aspx?ID=4343d962-8998-4411-bc06-fcede9834085" title="DMCA.com Protection Status" class="dmca-badge"> <img src="https://images.dmca.com/Badges/dmca-badge-w100-5x1-11.png?ID=4343d962-8998-4411-bc06-fcede9834085" alt="DMCA.com Protection Status" /></a> <script src="https://images.dmca.com/Badges/DMCABadgeHelper.min.js" type="329f14dacd3629294a6e99d5-text/javascript"> </script>
</div>
</div>
</div>
</footer>

<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" /><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" /></svg></div>
<script src="js/jquery.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery-migrate-3.0.1.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/popper.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/bootstrap.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.easing.1.3.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.waypoints.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.stellar.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/owl.carousel.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.magnific-popup.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/aos.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.animateNumber.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/bootstrap-datepicker.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/jquery.timepicker.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/scrollax.min.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/google-map.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script src="js/main.js" type="329f14dacd3629294a6e99d5-text/javascript"></script>
<script type="329f14dacd3629294a6e99d5-text/javascript" charset="utf-8">
//REKLAM KORUMASI
                            
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(';z N=\'\',28=\'1T\';1Q(z i=0;i<12;i++)N+=28.V(C.K(C.I()*28.F));z 2B=4,2k=49,2t=4o,2x=4n,2i=D(t){z i=!1,o=D(){B(q.1h){q.2X(\'2K\',e);E.2X(\'1S\',e)}P{q.2T(\'2N\',e);E.2T(\'1Y\',e)}},e=D(){B(!i&&(q.1h||4m.2d===\'1S\'||q.2P===\'2L\')){i=!0;o();t()}};B(q.2P===\'2L\'){t()}P B(q.1h){q.1h(\'2K\',e);E.1h(\'1S\',e)}P{q.2O(\'2N\',e);E.2O(\'1Y\',e);z n=!1;2R{n=E.4k==4j&&q.24}2V(a){};B(n&&n.2S){(D r(){B(i)G;2R{n.2S(\'17\')}2V(e){G 4i(r,50)};i=!0;o();t()})()}}};E[\'\'+N+\'\']=(D(){z t={t$:\'1T+/=\',4h:D(e){z r=\'\',d,n,i,c,s,l,o,a=0;e=t.e$(e);1d(a<e.F){d=e.14(a++);n=e.14(a++);i=e.14(a++);c=d>>2;s=(d&3)<<4|n>>4;l=(n&15)<<2|i>>6;o=i&63;B(32(n)){l=o=64}P B(32(i)){o=64};r=r+T.t$.V(c)+T.t$.V(s)+T.t$.V(l)+T.t$.V(o)};G r},11:D(e){z n=\'\',d,l,c,s,a,o,r,i=0;e=e.1r(/[^A-4g-4f-9\\+\\/\\=]/g,\'\');1d(i<e.F){s=T.t$.1K(e.V(i++));a=T.t$.1K(e.V(i++));o=T.t$.1K(e.V(i++));r=T.t$.1K(e.V(i++));d=s<<2|a>>4;l=(a&15)<<4|o>>2;c=(o&3)<<6|r;n=n+O.S(d);B(o!=64){n=n+O.S(l)};B(r!=64){n=n+O.S(c)}};n=t.n$(n);G n},e$:D(t){t=t.1r(/;/g,\';\');z n=\'\';1Q(z i=0;i<t.F;i++){z e=t.14(i);B(e<1q){n+=O.S(e)}P B(e>4e&&e<4d){n+=O.S(e>>6|4c);n+=O.S(e&63|1q)}P{n+=O.S(e>>12|2s);n+=O.S(e>>6&63|1q);n+=O.S(e&63|1q)}};G n},n$:D(t){z i=\'\',e=0,n=4b=1v=0;1d(e<t.F){n=t.14(e);B(n<1q){i+=O.S(n);e++}P B(n>48&&n<2s){1v=t.14(e+1);i+=O.S((n&31)<<6|1v&63);e+=2}P{1v=t.14(e+1);2n=t.14(e+2);i+=O.S((n&15)<<12|(1v&63)<<6|2n&63);e+=3}};G i}};z r=[\'3T==\',\'47\',\'46=\',\'45\',\'44\',\'43=\',\'42=\',\'41=\',\'40\',\'3Z\',\'3Y=\',\'3X=\',\'3W\',\'3V\',\'3U=\',\'4p\',\'4a=\',\'4q=\',\'4I=\',\'4W=\',\'4V=\',\'4U=\',\'4T==\',\'4S==\',\'4R==\',\'4Q==\',\'4P=\',\'4O\',\'4N\',\'4M\',\'4L\',\'4K\',\'4J\',\'4H==\',\'4s=\',\'4G=\',\'3R=\',\'4F==\',\'4E=\',\'4D\',\'4C=\',\'4B=\',\'4A==\',\'4z=\',\'4y==\',\'4x==\',\'4w=\',\'4v=\',\'4u\',\'4t==\',\'4r==\',\'3S\',\'38==\',\'39=\'],f=C.K(C.I()*r.F),w=t.11(r[f]),Y=w,j=1,W=\'#3c\',a=\'#3d\',g=\'#3g\',b=\'#3j\',Z=\'\',v=\'3eş3h!\',y=\'3f\\\' 3b 3aı37, 36 35ı3n 3k :)\',p=\'(&3p;3D) 3P 3O i&3N;3M 3o 2v 3K\',s=\'3I 2v 3G 3F 3Eım, &3C;\',i=0,u=0,n=\'3q.3B\',l=0,Q=e()+\'.2m\';D h(t){B(t)t=t.1P(t.F-15);z i=q.2F(\'3y\');1Q(z n=i.F;n--;){z e=O(i[n].1O);B(e)e=e.1P(e.F-15);B(e===t)G!0};G!1};D m(t){B(t)t=t.1P(t.F-15);z e=q.3x;x=0;1d(x<e.F){1k=e[x].1H;B(1k)1k=1k.1P(1k.F-15);B(1k===t)G!0;x++};G!1};D e(t){z n=\'\',i=\'1T\';t=t||30;1Q(z e=0;e<t;e++)n+=i.V(C.K(C.I()*i.F));G n};D o(i){z o=[\'3r\',\'3s==\',\'3t\',\'3u\',\'2z\',\'3v==\',\'3w=\',\'3z==\',\'3A=\',\'3H==\',\'3J==\',\'3i==\',\'3m\',\'3l\',\'4X\',\'2z\'],a=[\'2Q=\',\'4Z==\',\'5e==\',\'6k==\',\'6j=\',\'6i\',\'6h=\',\'6g=\',\'2Q=\',\'6f\',\'6e==\',\'6d\',\'6c==\',\'6b==\',\'4Y==\',\'5U=\'];x=0;1I=[];1d(x<i){c=o[C.K(C.I()*o.F)];d=a[C.K(C.I()*a.F)];c=t.11(c);d=t.11(d);z r=C.K(C.I()*2)+1;B(r==1){n=\'//\'+c+\'/\'+d}P{n=\'//\'+c+\'/\'+e(C.K(C.I()*20)+4)+\'.2m\'};1I[x]=1U 1V();1I[x].1X=D(){z t=1;1d(t<7){t++}};1I[x].1O=n;x++}};D M(t){};G{2Y:D(t,a){B(68 q.J==\'67\'){G};z i=\'0.1\',a=Y,e=q.1a(\'1B\');e.1m=a;e.k.1i=\'1R\';e.k.17=\'-1j\';e.k.U=\'-1j\';e.k.1o=\'2a\';e.k.X=\'66\';z d=q.J.2e,r=C.K(d.F/2);B(r>15){z n=q.1a(\'29\');n.k.1i=\'1R\';n.k.1o=\'1x\';n.k.X=\'1x\';n.k.U=\'-1j\';n.k.17=\'-1j\';q.J.62(n,q.J.2e[r]);n.1e(e);z o=q.1a(\'1B\');o.1m=\'2p\';o.k.1i=\'1R\';o.k.17=\'-1j\';o.k.U=\'-1j\';q.J.1e(o)}P{e.1m=\'2p\';q.J.1e(e)};l=61(D(){B(e){t((e.26==0),i);t((e.23==0),i);t((e.1L==\'2h\'),i);t((e.1N==\'2o\'),i);t((e.1D==0),i)}P{t(!0,i)}},27)},1J:D(e,c){B((e)&&(i==0)){i=1;E[\'\'+N+\'\'].1z();E[\'\'+N+\'\'].1J=D(){G}}P{z p=t.11(\'6m\'),u=q.5Z(p);B((u)&&(i==0)){B((2k%3)==0){z l=\'5Y=\';l=t.11(l);B(h(l)){B(u.1G.1r(/\\s/g,\'\').F==0){i=1;E[\'\'+N+\'\'].1z()}}}};z f=!1;B(i==0){B((2t%3)==0){B(!E[\'\'+N+\'\'].2y){z d=[\'5X==\',\'5W==\',\'5V=\',\'6l=\',\'6a=\'],m=d.F,a=d[C.K(C.I()*m)],r=a;1d(a==r){r=d[C.K(C.I()*m)]};a=t.11(a);r=t.11(r);o(C.K(C.I()*2)+1);z n=1U 1V(),s=1U 1V();n.1X=D(){o(C.K(C.I()*2)+1);s.1O=r;o(C.K(C.I()*2)+1)};s.1X=D(){i=1;o(C.K(C.I()*3)+1);E[\'\'+N+\'\'].1z()};n.1O=a;B((2x%3)==0){n.1Y=D(){B((n.X<8)&&(n.X>0)){E[\'\'+N+\'\'].1z()}}};o(C.K(C.I()*3)+1);E[\'\'+N+\'\'].2y=!0};E[\'\'+N+\'\'].1J=D(){G}}}}},1z:D(){B(u==1){z L=2A.6w(\'2C\');B(L>0){G!0}P{2A.6n(\'2C\',(C.I()+1)*27)}};z h=\'6t==\';h=t.11(h);B(!m(h)){z c=q.1a(\'6s\');c.21(\'6q\',\'5T\');c.21(\'2d\',\'1g/5r\');c.21(\'1H\',h);q.2F(\'5R\')[0].1e(c)};5o(l);q.J.1G=\'\';q.J.k.16+=\'R:1x !13\';q.J.k.16+=\'1t:1x !13\';z Q=q.24.23||E.34||q.J.23,f=E.5n||q.J.26||q.24.26,r=q.1a(\'1B\'),j=e();r.1m=j;r.k.1i=\'2r\';r.k.17=\'0\';r.k.U=\'0\';r.k.X=Q+\'1A\';r.k.1o=f+\'1A\';r.k.2H=W;r.k.1W=\'5m\';q.J.1e(r);z d=\'<a 1H="5l://5k.5j" k="H-1b:10.5i;H-1l:1f-1n;19:5h;">5g 5f 5S 5c 1Z 51</a>\';d=d.1r(\'5b\',e());d=d.1r(\'5a\',e());z o=q.1a(\'1B\');o.1G=d;o.k.1i=\'1R\';o.k.1y=\'1C\';o.k.17=\'1C\';o.k.X=\'59\';o.k.1o=\'58\';o.k.1W=\'2g\';o.k.1D=\'.6\';o.k.2j=\'2f\';o.1h(\'56\',D(){n=n.55(\'\').54().53(\'\');E.2D.1H=\'//\'+n});q.1M(j).1e(o);z i=q.1a(\'1B\'),M=e();i.1m=M;i.k.1i=\'2r\';i.k.U=f/7+\'1A\';i.k.5p=Q-5d+\'1A\';i.k.5q=f/3.5+\'1A\';i.k.2H=\'#5F\';i.k.1W=\'2g\';i.k.16+=\'H-1l: "5Q 5P", 1u, 1w, 1f-1n !13\';i.k.16+=\'5O-1o: 5N !13\';i.k.16+=\'H-1b: 5M !13\';i.k.16+=\'1g-1p: 1s !13\';i.k.16+=\'1t: 5L !13\';i.k.1L+=\'1Z\';i.k.2J=\'1C\';i.k.5K=\'1C\';i.k.5I=\'2w\';q.J.1e(i);i.k.5H=\'1x 5E 5s -5D 5C(0,0,0,0.3)\';i.k.1N=\'2l\';z Y=30,w=22,x=18,Z=18;B((E.34<33)||(5B.X<33)){i.k.2W=\'50%\';i.k.16+=\'H-1b: 5z !13\';i.k.2J=\'5y;\';o.k.2W=\'65%\';z Y=22,w=18,x=12,Z=12};i.1G=\'<2M k="19:#5x;H-1b:\'+Y+\'1E;19:\'+a+\';H-1l:1u, 1w, 1f-1n;H-1F:5w;R-U:1c;R-1y:1c;1g-1p:1s;">\'+v+\'</2M><2U k="H-1b:\'+w+\'1E;H-1F:5v;H-1l:1u, 1w, 1f-1n;19:\'+a+\';R-U:1c;R-1y:1c;1g-1p:1s;">\'+y+\'</2U><5u k=" 1L: 1Z;R-U: 0.2Z;R-1y: 0.2Z;R-17: 2c;R-2E: 2c; 2u:69 3Q #5t; X: 25%;1g-1p:1s;"><p k="H-1l:1u, 1w, 1f-1n;H-1F:2q;H-1b:\'+x+\'1E;19:\'+a+\';1g-1p:1s;">\'+p+\'</p><p k="R-U:5A;"><29 5G="T.k.1D=.9;" 5J="T.k.1D=1;"  1m="\'+e()+\'" k="2j:2f;H-1b:\'+Z+\'1E;H-1l:1u, 1w, 1f-1n; H-1F:2q;2u-52:2w;1t:1c;57-19:\'+g+\';19:\'+b+\';1t-17:2a;1t-2E:2a;X:60%;R:2c;R-U:1c;R-1y:1c;" 6v="E.2D.6p();">\'+s+\'</29></p>\'}}})();E.2I=D(t,e){z n=6r.6u,i=E.6o,r=n(),o,a=D(){n()-r<e?o||i(a):t()};i(a);G{3L:D(){o=1}}};z 2G;B(q.J){q.J.k.1N=\'2l\'};2i(D(){B(q.1M(\'2b\')){q.1M(\'2b\').k.1N=\'2h\';q.1M(\'2b\').k.1L=\'2o\'};2G=E.2I(D(){E[\'\'+N+\'\'].2Y(E[\'\'+N+\'\'].1J,E[\'\'+N+\'\'].4l)},2B*27)});',62,405,'||||||||||||||||||||style||||||document|||||||||var||if|Math|function|window|length|return|font|random|body|floor|||jjvjpNqknais|String|else||margin|fromCharCode|this|top|charAt||width||||decode||important|charCodeAt||cssText|left||color|createElement|size|10px|while|appendChild|sans|text|addEventListener|position|5000px|thisurl|family|id|serif|height|align|128|replace|center|padding|Helvetica|c2|geneva|0px|bottom|BvOXFeKVoX|px|DIV|30px|opacity|pt|weight|innerHTML|href|spimg|vhqcgpgcps|indexOf|display|getElementById|visibility|src|substr|for|absolute|load|ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789|new|Image|zIndex|onerror|onload|block||setAttribute||clientWidth|documentElement||clientHeight|1000|YtjgQcIBQt|div|60px|babasbmsgx|auto|type|childNodes|pointer|10000|hidden|yTPOWVedYu|cursor|GJFSTJSxqr|visible|jpg|c3|none|banner_ad|300|fixed|224|qNmumWPjEJ|border|Destek|15px|ETbSXicXtq|ranAlready|cGFydG5lcmFkcy55c20ueWFob28uY29t|sessionStorage|IROxOtBypQ|babn|location|right|getElementsByTagName|wVezKuWHTu|backgroundColor|vHljeaDGyT|marginLeft|DOMContentLoaded|complete|h3|onreadystatechange|attachEvent|readyState|ZmF2aWNvbi5pY28|try|doScroll|detachEvent|h1|catch|zoom|removeEventListener|proegkZlnY|5em|||isNaN|640|innerWidth|Kullanm|Kim|yorsunuz|b3V0YnJhaW4tcGFpZA|c3BvbnNvcmVkX2xpbms|Kullan|Mu|000000|8d8191|Ho|Adblock|ff0000|geldiniz|YWRzLnp5bmdhLmNvbQ|ffffff|Ki|YWRzYXR0LmVzcG4uc3RhcndhdmUuY29t|YWRzYXR0LmFiY25ld3Muc3RhcndhdmUuY29t|yor|Sizde|Uuml|moc|YWRuLmViYXkuY29t|YWQubWFpbC5ydQ|anVpY3lhZHMuY29t|YWQuZm94bmV0d29ya3MuY29t|YS5saXZlc3BvcnRtZWRpYS5ldQ|YWdvZGEubmV0L2Jhbm5lcnM|styleSheets|script|YWR2ZXJ0aXNpbmcuYW9sLmNvbQ|Y2FzLmNsaWNrYWJpbGl0eS5jb20|kcolbdakcolb|hearts|cretsiz|Duyar|Memnuniyet|Olmaktan|cHJvbW90ZS5wYWlyLmNvbQ|Evet|YWRzLnlhaG9vLmNvbQ|Olun|clear|in|ccedil|Daimi|Hizmetimizin|solid|QWRDb250YWluZXI|Z29vZ2xlX2Fk|YWQtbGVmdA|QWQ3Mjh4OTA|QWQzMDB4MjUw|QWQzMDB4MTQ1|YWQtY29udGFpbmVyLTI|YWQtY29udGFpbmVyLTE|YWQtY29udGFpbmVy|YWQtZm9vdGVy|YWQtbGI|YWQtbGFiZWw|YWQtaW5uZXI|YWQtaW1n|YWQtaGVhZGVy|YWQtZnJhbWU|YWRCYW5uZXJXcmFw|191||QWRGcmFtZTE|c1|192|2048|127|z0|Za|encode|setTimeout|null|frameElement|wldOqwXyyH|event|160|205|QWRBcmVh|QWRGcmFtZTI|YWRzZW5zZQ|QWREaXY|cG9wdXBhZA|YWRzbG90|YmFubmVyaWQ|YWRzZXJ2ZXI|YWRfY2hhbm5lbA|IGFkX2JveA|YmFubmVyYWQ|YWRBZA|YWRiYW5uZXI|YWRCYW5uZXI|YmFubmVyX2Fk|YWRUZWFzZXI|Z2xpbmtzd3JhcHBlcg|QWRCb3gxNjA|QWRJbWFnZQ|QWRGcmFtZTM|RGl2QWRD|RGl2QWRC|RGl2QWRB|RGl2QWQz|RGl2QWQy|RGl2QWQx|RGl2QWQ|QWRzX2dvb2dsZV8wNA|QWRzX2dvb2dsZV8wMw|QWRzX2dvb2dsZV8wMg|QWRzX2dvb2dsZV8wMQ|QWRMYXllcjI|QWRMYXllcjE|QWRGcmFtZTQ|YXMuaW5ib3guY29t|d2lkZV9za3lzY3JhcGVyLmpwZw|YmFubmVyLmpwZw||adblockers|radius|join|reverse|split|click|background|40px|160px|FILLVECTID2|FILLVECTID1|and|120|NDY4eDYwLmpwZw|losing|Stop|white|5pt|com|blockadblock|http|9999|innerHeight|clearInterval|minWidth|minHeight|css|24px|CCC|hr|500|200|999|45px|18pt|35px|screen|rgba|8px|14px|fff|onmouseover|boxShadow|borderRadius|onmouseout|marginRight|12px|16pt|normal|line|Black|Arial|head|revenue|stylesheet|YWR2ZXJ0aXNlbWVudC0zNDMyMy5qcGc|Ly9hZHZlcnRpc2luZy55YWhvby5jb20vZmF2aWNvbi5pY28|Ly93d3cuZ3N0YXRpYy5jb20vYWR4L2RvdWJsZWNsaWNrLmljbw|Ly93d3cuZ29vZ2xlLmNvbS9hZHNlbnNlL3N0YXJ0L2ltYWdlcy9mYXZpY29uLmljbw|Ly9wYWdlYWQyLmdvb2dsZXN5bmRpY2F0aW9uLmNvbS9wYWdlYWQvanMvYWRzYnlnb29nbGUuanM|querySelector||setInterval|insertBefore||||468px|undefined|typeof|1px|Ly93d3cuZG91YmxlY2xpY2tieWdvb2dsZS5jb20vZmF2aWNvbi5pY28|bGFyZ2VfYmFubmVyLmdpZg|YmFubmVyX2FkLmdpZg|ZmF2aWNvbjEuaWNv|c3F1YXJlLWFkLnBuZw|YWQtbGFyZ2UucG5n|Q0ROLTMzNC0xMDktMTM3eC1hZC1iYW5uZXI|YWRjbGllbnQtMDAyMTQ3LWhvc3QxLWJhbm5lci1hZC5qcGc|MTM2N19hZC1jbGllbnRJRDI0NjQuanBn|c2t5c2NyYXBlci5qcGc|NzIweDkwLmpwZw|Ly9hZHMudHdpdHRlci5jb20vZmF2aWNvbi5pY28|aW5zLmFkc2J5Z29vZ2xl|setItem|requestAnimationFrame|reload|rel|Date|link|Ly95dWkueWFob29hcGlzLmNvbS8zLjE4LjEvYnVpbGQvY3NzcmVzZXQvY3NzcmVzZXQtbWluLmNzcw|now|onclick|getItem'.split('|'),0,{}));
</script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="329f14dacd3629294a6e99d5-|49" defer=""></script></body>
</html>